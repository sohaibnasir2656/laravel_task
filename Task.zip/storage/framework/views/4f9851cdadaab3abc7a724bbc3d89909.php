<?php $__env->startSection('title'); ?>
    Employee Detail
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="breadcrumbs">
    <div class="col-sm-4">
        <div class="page-header float-left">
            <div class="page-title">
                <h1>Dashboard</h1>
            </div>
        </div>
    </div>
    <div class="col-sm-8">
        <div class="page-header float-right">
            <div class="page-title">
                <ol class="breadcrumb text-right">
                    <li><a href="#">Dashboard</a></li>
                    <li><a href="<?php echo e(route('employees.index')); ?>">Employees</a></li>
                    <li class="active">Employee Detail</li>
                </ol>
            </div>
        </div>
    </div>
</div>
<div class="col-lg-12">
    <div class="card">
        <div class="card-header">
            <strong class="card-title">Employe Detail</strong>
        </div>
        <div class="card-body">
            <table class="table">
                <tbody>
                    <tr>
                        <th>First Name</th>
                        <td><?php echo e($employee->first_name); ?></td>
                    </tr>
                    <tr>
                        <th>Last Name</th>
                        <td><?php echo e($employee->last_name); ?></td>
                    </tr>
                    <tr>
                        <th>Company Name</th>
                        <td><?php echo e($employee->company->name); ?></td>
                    </tr>
                    <tr>
                        <th>Email</th>
                        <td><?php echo e($employee->email); ?></td>
                    </tr>
                    <tr>
                        <th>Phone No</th>
                        <td><?php echo e($employee->phone); ?></td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="col-lg-12">
    <div class="card">
        <div class="card-header">
            <strong class="card-title">Company Detail</strong>
        </div>
        <div class="card-body">
            <table class="table">
                <tbody>
                    <tr>
                        <th>Company Name</th>
                        <td><?php echo e($employee->company->name); ?></td>
                    </tr>
                    <tr>
                        <th>Company Email</th>
                        <td><?php echo e($employee->company->email); ?></td>
                    </tr>
                    <tr>
                        <th>Company Website</th>
                        <td><?php echo e($employee->company->website); ?></td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Task\resources\views/admin/employees/show.blade.php ENDPATH**/ ?>