<?php $__env->startSection('title'); ?>
    Company Detail
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="breadcrumbs">
    <div class="col-sm-4">
        <div class="page-header float-left">
            <div class="page-title">
                <h1>Dashboard</h1>
            </div>
        </div>
    </div>
    <div class="col-sm-8">
        <div class="page-header float-right">
            <div class="page-title">
                <ol class="breadcrumb text-right">
                    <li><a href="#">Dashboard</a></li>
                    <li><a href="<?php echo e(route('companies.index')); ?>">Company</a></li>
                    <li class="active">Company Detail</li>
                </ol>
            </div>
        </div>
    </div>
</div>
<div class="col-lg-12">
    <div class="card">
        <div class="card-header">
            <strong class="card-title">Company Detail</strong>
        </div>
        <div class="card-body">
            <table class="table">
                <tbody>
                    <tr>
                        <th>Company Logo</th>
                        <td><img src="<?php echo e(asset('storage/' . $company->logo)); ?>" alt="Company Logo" style="max-width: 100px;"></td>
                    </tr>
                    <tr>
                        <th>Name</th>
                        <td><?php echo e($company->name); ?></td>
                    </tr>
                    <tr>
                        <th>Email</th>
                        <td><?php echo e($company->email); ?></td>
                    </tr>
                    <tr>
                        <th>Website</th>
                        <td><a href="<?php echo e($company->website); ?>" target="_blank"><?php echo e($company->website); ?></a></td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Task\resources\views/admin/companies/show.blade.php ENDPATH**/ ?>